سامانه ثبت اسناد آزادگان - بسته آماده GitHub Actions

روش استفاده:
1) این ZIP را در رایانه یا گوشی از حالت فشرده خارج کنید.
2) در مخزن GitHub از Code > Add file > Upload files، تمام محتویات این پوشه را (همراه پوشه مخفی .github) بارگذاری و Commit کنید.
3) وارد Actions شوید و workflow با نام Build Android APK را اجرا کنید.
4) پس از پایان موفق، در صفحه اجرای Action از بخش Artifacts فایل Asnad-Azadegan-APK را دانلود کنید.

فایل HTML نهایی داخل app/src/main/assets/index.html قرار دارد.
