
const $=id=>document.getElementById(id),today=new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()).replace(/-/g,'/');
// انتخابگر داخلی تقویم شمسی؛ بدون وابستگی به اینترنت یا کتابخانه خارجی
const jalaliPartsFmt=new Intl.DateTimeFormat('en-u-ca-persian-nu-latn',{year:'numeric',month:'numeric',day:'numeric'});
const jalaliLabelFmt=new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'long'});
const jalaliValueFmt=new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'2-digit',day:'2-digit'});
const persianDigits=s=>String(s||'').replace(/[۰-۹٠-٩]/g,c=>'۰۱۲۳۴۵۶۷۸۹'[('۰۱۲۳۴۵۶۷۸۹'.indexOf(c)>=0)?'۰۱۲۳۴۵۶۷۸۹'.indexOf(c):'٠١٢٣٤٥٦٧٨٩'.indexOf(c)]);
const latinDigits=s=>String(s||'').replace(/[۰-۹٠-٩]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c)>=0?'۰۱۲۳۴۵۶۷۸۹'.indexOf(c):'٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
function jParts(d){const o={};jalaliPartsFmt.formatToParts(d).forEach(p=>{if(p.type==='year'||p.type==='month'||p.type==='day')o[p.type]=Number(p.value)});return o}
function jFirstDay(d){let x=new Date(d.getFullYear(),d.getMonth(),d.getDate());for(let i=0;i<31&&jParts(x).day!==1;i++)x.setDate(x.getDate()-1);return x}
function findJalaliDate(value){const m=latinDigits(value).match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/);if(!m)return new Date();const target={year:+m[1],month:+m[2],day:+m[3]};let d=new Date(target.year+621,2,1);d.setDate(d.getDate()-120);for(let i=0;i<500;i++,d.setDate(d.getDate()+1)){const q=jParts(d);if(q.year===target.year&&q.month===target.month&&q.day===target.day)return new Date(d.getFullYear(),d.getMonth(),d.getDate())}return new Date()}
const dateOverlay=document.createElement('div');dateOverlay.className='date-picker-overlay';dateOverlay.innerHTML='<div class="date-picker-panel" role="dialog" aria-modal="true" aria-label="انتخاب تاریخ شمسی"><div class="date-picker-head"><button type="button" class="secondary" id="jalaliPrev">ماه قبل</button><strong id="jalaliMonthTitle"></strong><button type="button" class="secondary" id="jalaliNext">ماه بعد</button></div><div class="date-picker-grid" id="jalaliCalendar"></div><div class="date-picker-foot"><button type="button" class="secondary" id="jalaliToday">امروز</button><button type="button" class="secondary" id="jalaliCancel">انصراف</button></div></div>';
document.body.appendChild(dateOverlay);
let activeDateInput=null,calendarMonth=new Date();
function closeJalaliPicker(){dateOverlay.style.display='none';activeDateInput=null}
function renderJalaliCalendar(){const first=jFirstDay(calendarMonth),p=jParts(first);$('jalaliMonthTitle').textContent=jalaliLabelFmt.format(first);const grid=$('jalaliCalendar');grid.innerHTML='';['ش','ی','د','س','چ','پ','ج'].forEach(x=>{const h=document.createElement('span');h.textContent=x;grid.appendChild(h)});const offset=(first.getDay()+1)%7;for(let i=0;i<42;i++){const d=new Date(first.getFullYear(),first.getMonth(),first.getDate()+i-offset),q=jParts(d),b=document.createElement('button');b.type='button';b.textContent=Number(q.day).toLocaleString('fa-IR');if(q.month!==p.month||q.year!==p.year)b.classList.add('other-month');if(activeDateInput&&latinDigits(activeDateInput.value).match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/)?.slice(1).map(Number).join('/')===[q.year,q.month,q.day].join('/'))b.classList.add('selected');b.addEventListener('click',()=>{if(activeDateInput){activeDateInput.value=jalaliValueFmt.format(d).replace(/-/g,'/');activeDateInput.dispatchEvent(new Event('change'))}closeJalaliPicker()});grid.appendChild(b)}}
function openJalaliPicker(input){activeDateInput=input;calendarMonth=findJalaliDate(input.value);dateOverlay.style.display='flex';renderJalaliCalendar()}
$('jalaliPrev').addEventListener('click',()=>{const f=jFirstDay(calendarMonth);calendarMonth=new Date(f.getFullYear(),f.getMonth(),f.getDate()-1);renderJalaliCalendar()});
$('jalaliNext').addEventListener('click',()=>{const f=jFirstDay(calendarMonth);calendarMonth=new Date(f.getFullYear(),f.getMonth(),f.getDate()+35);renderJalaliCalendar()});
$('jalaliToday').addEventListener('click',()=>{if(activeDateInput){activeDateInput.value=today;activeDateInput.dispatchEvent(new Event('change'))}closeJalaliPicker()});$('jalaliCancel').addEventListener('click',closeJalaliPicker);dateOverlay.addEventListener('click',e=>{if(e.target===dateOverlay)closeJalaliPicker()});
['docdate','deliveryDate','receiptDate','dateFrom','dateTo','dateExact'].forEach(id=>{const el=$(id);if(!el)return;el.readOnly=true;el.dataset.jalaliPicker='1';el.setAttribute('aria-label','برای انتخاب تاریخ شمسی لمس کنید');el.addEventListener('click',()=>openJalaliPicker(el));});
// اسکن بارکد با دوربین گوشی (نیازمند پشتیبانی مرورگر و اجازه دسترسی دوربین)
let scannerStream=null,scannerTimer=null,scannerDetector=null,scannerBusy=false;
function stopBarcodeScanner(){
 if(scannerTimer){clearTimeout(scannerTimer);scannerTimer=null}
 if(scannerStream){scannerStream.getTracks().forEach(t=>t.stop());scannerStream=null}
 const v=$('scannerVideo');if(v)v.srcObject=null;
 $('scannerOverlay').style.display='none';scannerBusy=false;
}
async function startBarcodeScanner(){
 const overlay=$('scannerOverlay'),msg=$('scannerMessage'),video=$('scannerVideo');
 overlay.style.display='flex';msg.textContent='در حال آماده‌سازی دوربین...';
 if(!navigator.mediaDevices?.getUserMedia){msg.textContent='مرورگر اجازه باز کردن دوربین را نمی‌دهد. صفحه را در Chrome و از یک بستر امن (HTTPS) باز کنید.';return}
 try{
  if('BarcodeDetector' in window){
   let formats=['code_128','code_39','ean_13','ean_8','upc_a','upc_e','itf','codabar','qr_code'];
   if(BarcodeDetector.getSupportedFormats){const supported=await BarcodeDetector.getSupportedFormats();formats=formats.filter(f=>supported.includes(f));}
   scannerDetector=new BarcodeDetector({formats});
  }
  scannerStream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:'environment'}}});
  video.srcObject=scannerStream;await video.play();msg.textContent='دوربین را مقابل بارکد مرسوله بگیرید؛ اسکن به‌صورت خودکار انجام می‌شود.';
  scannerBusy=false;
  const scan=async()=>{
   if(!scannerStream||scannerBusy)return;
   if(video.readyState>=2 && scannerDetector){
    try{const found=await scannerDetector.detect(video);if(found&&found.length&&found[0].rawValue){
     const value=found[0].rawValue.trim();$('barcode').value=value;$('barcode').dispatchEvent(new Event('input',{bubbles:true}));
     msg.textContent='بارکد خوانده شد: '+value+'؛ حالا دکمه خواندن نوشته‌های بارنامه را بزنید.';scannerBusy=true;return;
    }}catch(e){}
   }
   if(scannerStream)scannerTimer=setTimeout(scan,180);
  };
  scan();
 }catch(err){
  let message='باز کردن دوربین ناموفق بود. اجازه دسترسی دوربین را فعال کنید و دوباره تلاش کنید.';
  if(err&&err.name==='NotAllowedError')message='اجازه دسترسی به دوربین داده نشد. از تنظیمات سایت، دسترسی Camera را فعال کنید.';
  else if(err&&err.name==='NotFoundError')message='دوربین قابل استفاده‌ای در گوشی پیدا نشد.';
  msg.textContent=message;
  if(scannerStream){scannerStream.getTracks().forEach(t=>t.stop());scannerStream=null}
 }
}
// خواندن نوشته‌های بارنامه با OCR؛ فقط فیلدهای موجود در سامانه پر می‌شوند.
function faDigits(v){return String(v||'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));}
function cleanDigits(v){return faDigits(v).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[^0-9]/g,'');}
function normalizeOcrText(v){return String(v||'').replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[‌‏]/g,' ').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));}
function extractLabelFields(text){
 const normalized=normalizeOcrText(text);
 const lines=normalized.split(/\n+/).map(x=>x.trim()).filter(Boolean);
 let mobile='';
 const all=normalized.replace(/[^0-9]/g,' ');
 const phones=all.match(/09\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d/g)||[];
 if(phones.length) mobile=phones[phones.length-1];
 let name='',office='';
 for(let i=0;i<lines.length;i++){
  const line=lines[i].replace(/[\s:：]/g,'');
  if(!name && /نام(?:و)?نام?خانوادگی|نام.?گیرنده|گیرنده/.test(line)){
   const candidate=(lines[i].split(/[:：]/).slice(1).join(':').trim()||lines[i].replace(/.*?(?:نام\s*و?\s*نام\s*خانوادگی|نام\s*گیرنده|گیرنده)\s*/,'').trim()||lines[i+1]||'').trim();
   if(candidate && !/تلفن|موبایل|آدرس|کدپستی|دفترخانه/.test(candidate)) name=candidate;
  }
  if(!office && /دفترخانه/.test(line)){
   let candidate=(lines[i].split(/[:：]/).slice(1).join(':').trim()||lines[i].replace(/.*دفترخانه\s*/,'')).trim();
   if(!candidate){
    for(let j=i+1;j<Math.min(lines.length,i+3);j++){
     const next=lines[j].trim();
     if(next && !/تاریخ|شماره|بارکد|گیرنده|تلفن|موبایل|آدرس|کدپستی/.test(next)){candidate=next;break;}
    }
   }
   candidate=candidate.replace(/^(نام\s*)?(دفترخانه\s*)/,'').trim();
   if(candidate && !/^[:：\-]*$/.test(candidate)) office=candidate;
  }
 }
 return {mobile,name,office};
}
// موتور OCR و مدل زبان فقط یک‌بار ساخته می‌شوند و برای اسکن‌های بعدی نگه داشته می‌شوند.
let ocrWorkerPromise=null,ocrBusy=false;
async function getOcrWorker(msg){
 if(!window.Tesseract){await new Promise((resolve,reject)=>{const sc=document.createElement('script');sc.src='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';sc.onload=resolve;sc.onerror=reject;document.head.appendChild(sc)});}
 if(!ocrWorkerPromise){
  ocrWorkerPromise=Tesseract.createWorker('fas+eng',1,{logger:m=>{if(msg&&m.status==='recognizing text')msg.textContent='در حال تشخیص متن: '+Math.round((m.progress||0)*100)+'٪';}}).then(async worker=>{try{await worker.setParameters({tessedit_pageseg_mode:'6'});}catch(e){}return worker;}).catch(e=>{ocrWorkerPromise=null;throw e;});
 }
 return await ocrWorkerPromise;
}
$('readLabel').addEventListener('click',async()=>{
 const video=$('scannerVideo'),msg=$('scannerMessage'),button=$('readLabel');
 if(ocrBusy)return;
 if(!video.videoWidth){msg.textContent='ابتدا دوربین را باز کنید و بارنامه را در کادر قرار دهید.';return}
 ocrBusy=true;button.disabled=true;msg.textContent='در حال آماده‌سازی خواندن متن...';
 try{
  const worker=await getOcrWorker(msg);
  // کاهش اندازه تصویر تا OCR سریع‌تر شود، بدون تغییر نسبت تصویر.
  const c=$('ocrCanvas'),scale=Math.min(1,1600/video.videoWidth);
  c.width=Math.round(video.videoWidth*scale);c.height=Math.round(video.videoHeight*scale);
  const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(video,0,0,c.width,c.height);
  const result=await worker.recognize(c);
  const fields=extractLabelFields(result.data.text||'');
  if(fields.office){$('office').value=fields.office;$('office').dispatchEvent(new Event('input',{bubbles:true}));}
  if(fields.name){$('fullname').value=fields.name;$('fullname').dispatchEvent(new Event('input',{bubbles:true}));}
  if(fields.mobile){$('mobile').value=fields.mobile;$('mobile').dispatchEvent(new Event('input',{bubbles:true}));}
  const raw=normalizeOcrText(result.data.text||'');
  const nums=raw.match(/\d{10,20}/g)||[];
  if(!$('barcode').value && nums.length){$('barcode').value=nums[0];$('barcode').dispatchEvent(new Event('input',{bubbles:true}));}
  const found=[];if(fields.office)found.push('نام دفترخانه');if(fields.name)found.push('نام گیرنده');if(fields.mobile)found.push('موبایل گیرنده');if($('barcode').value)found.push('شماره بارنامه/بارکد');
  msg.textContent=found.length?'تشخیص انجام شد ('+found.join('، ')+'). فیلدها را بررسی و در صورت نیاز اصلاح کنید، سپس دوربین را ببندید.':'متن خوانده شد اما فیلدهای موردنظر با اطمینان تشخیص داده نشدند؛ لطفاً واضح‌تر عکس بگیرید یا دستی وارد کنید.';
 }catch(e){msg.textContent='خواندن متن ناموفق بود. اتصال اینترنت و اجازه دسترسی برنامه به اینترنت را بررسی کنید؛ بارنامه را واضح و روبه‌روی دوربین نگه دارید و دوباره تلاش کنید.';}
 finally{ocrBusy=false;button.disabled=false;}
});
$('openScanner').addEventListener('click',startBarcodeScanner);
$('closeScanner').addEventListener('click',stopBarcodeScanner);
$('scannerOverlay').addEventListener('click',e=>{if(e.target===$('scannerOverlay'))stopBarcodeScanner()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('scannerOverlay').style.display==='flex')stopBarcodeScanner()});

let records=JSON.parse(localStorage.getItem('registry_docs_v2')||'[]'),filter='all',selected=new Set();
const jalali=s=>{if(!s)return s;const m=String(s).match(/^(\d{4})-(\d{2})-(\d{2})$/);return m?new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(+m[1],+m[2]-1,+m[3])).replace(/-/g,'/'):s};
records.forEach(r=>{r.docdate=jalali(r.docdate);r.deliveryDate=jalali(r.deliveryDate);r.receiptDate=jalali(r.receiptDate);r.receiptSigner=r.receiptSigner||''});
const fa=n=>Number(n).toLocaleString('fa-IR');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function save(){localStorage.setItem('registry_docs_v2',JSON.stringify(records));render()}
function status(r){return r.receiptDate?'دریافت‌شده':r.deliveryDate?'تحویل‌شده':'در انتظار تحویل'}
function render(){
 const query=latinDigits(($('searchDocs')?.value||'').trim()).toLocaleLowerCase(),from=latinDigits($('dateFrom').value).replace(/-/g,'/'),to=latinDigits($('dateTo').value).replace(/-/g,'/'),exact=latinDigits($('dateExact').value||'').replace(/-/g,'/');
 const visible=records.filter(r=>{const d=latinDigits(r.docdate||'').replace(/-/g,'/');return (!exact||d===exact)&&(!from||d>=from)&&(!to||d<=to)&&(filter==='all'||(filter==='pending'&&!r.deliveryDate)||(filter==='delivered'&&r.deliveryDate&&!r.receiptDate)||(filter==='received'&&r.receiptDate))&&(!query||[r.office,r.docdate,r.barcode,r.fullname,r.mobile,r.deliveryDate,r.deliverySigner,r.registryUnit,r.receiptDate,r.receiptSigner,status(r)].some(v=>latinDigits(String(v||'')).toLocaleLowerCase().includes(query)));});
 $('rows').innerHTML=visible.length?visible.map((r,i)=>`<tr><td class="noprint"><input type="checkbox" aria-label="انتخاب سند" ${selected.has(r.id)?'checked':''} onchange="toggle('${r.id}',this.checked)"></td><td>${fa(i+1)}</td><td class="noprint"><button class="edit-btn" type="button" onclick="editRecord('${r.id}')">ویرایش</button></td><td>${esc(r.office)}</td><td>${esc(r.docdate)}</td><td>${esc(r.barcode)}</td><td>${esc(r.fullname)}</td><td>${esc(r.mobile)}</td><td>${esc(r.deliveryDate||'—')} ${r.deliverySig?'<span class="status done">امضا دارد</span>':''}</td><td>${esc(r.registryUnit||'—')}</td><td>${esc(r.receiptDate||'—')}</td><td>${r.deliverySig?`<img class="signature-print" src="${r.deliverySig}" alt="امضای تحویل"><div class="sig-name">${esc(r.deliverySigner||'')}</div>`:'—'}</td><td>${r.receiptSig?`<img class="signature-print" src="${r.receiptSig}" alt="امضای دریافت"><div class="sig-name">${esc(r.receiptSigner||'')}</div>`:(r.receiptSigner?`<div class="sig-name">${esc(r.receiptSigner)}</div>`:'—')}</td><td><span class="status ${r.receiptDate?'done':''}">${status(r)}</span></td></tr>`).join(''):'<tr><td colspan="14" class="empty">موردی برای نمایش وجود ندارد.</td></tr>';
 $('sAll').textContent=fa(records.length);$('sPending').textContent=fa(records.filter(r=>!r.deliveryDate).length);$('sDelivered').textContent=fa(records.filter(r=>r.deliveryDate&&!r.receiptDate).length);$('sReceived').textContent=fa(records.filter(r=>r.receiptDate).length);
 document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter===filter));
}
$('searchDocs').addEventListener('input',render);['dateFrom','dateTo','dateExact'].forEach(id=>$(id).addEventListener('change',render));
const listCard=$('docsListCard');function setListFullscreen(open){listCard.classList.toggle('fullscreen',open);document.body.style.overflow=open?'hidden':'';if(open){$('searchDocs').focus({preventScroll:true});}}
$('openListFullscreen').addEventListener('click',()=>setListFullscreen(true));$('closeListFullscreen').addEventListener('click',()=>setListFullscreen(false));
$('clearListFilters').addEventListener('click',()=>{['searchDocs','dateExact','dateFrom','dateTo'].forEach(id=>$(id).value='');filter='all';render()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&listCard.classList.contains('fullscreen'))setListFullscreen(false)});
window.toggle=(id,on)=>{on?selected.add(id):selected.delete(id)};
window.editRecord=id=>{const r=records.find(x=>x.id===id);if(!r)return;const ask=(label,value)=>{const v=prompt(label,value||'');return v===null?null:v.trim()};
 const office=ask('شماره دفترخانه',r.office);if(office===null)return;
 const docdate=ask('تاریخ سند شمسی',r.docdate);if(docdate===null)return;
 const barcode=ask('بارکد',r.barcode);if(barcode===null)return;
 const fullname=ask('نام و نام خانوادگی',r.fullname);if(fullname===null)return;
 const mobile=ask('شماره موبایل',r.mobile);if(mobile===null)return;
 if(!office||!docdate||!barcode||!fullname||!mobile){alert('فیلدهای اصلی نمی‌توانند خالی باشند.');return}
 if(records.some(x=>x.id!==id&&x.barcode===barcode)){alert('این بارکد برای سند دیگری ثبت شده است.');return}
 Object.assign(r,{office,docdate,barcode,fullname,mobile});save();alert('اطلاعات سند ویرایش شد.');};
$('add').onclick=()=>{
 const office=$('office').value.trim(),docdate=$('docdate').value,barcode=$('barcode').value.trim(),fullname=$('fullname').value.trim(),mobile=$('mobile').value.trim();
 if(!office||!docdate||!barcode||!fullname||!mobile){alert('لطفاً شماره دفترخانه، تاریخ، بارکد، نام و نام خانوادگی و موبایل را کامل کنید.');return}
 if(records.some(r=>r.barcode===barcode)){alert('این بارکد قبلاً ثبت شده است.');return}
 records.push({id:String(Date.now())+Math.random().toString(16).slice(2),office,docdate,barcode,fullname,mobile,deliveryDate:'',deliverySig:null,receiptDate:'',receiptSig:null});
 ['office','barcode','fullname','mobile'].forEach(id=>$(id).value='');save();alert('سند ثبت شد.');
};
document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;render()});
$('selectVisible').onclick=()=>{records.filter(r=>filter==='all'||(filter==='pending'&&!r.deliveryDate)||(filter==='delivered'&&r.deliveryDate&&!r.receiptDate)||(filter==='received'&&r.receiptDate)).forEach(r=>selected.add(r.id));render()};
$('unselect').onclick=()=>{selected.clear();render()};
$('deleteSelected').onclick=()=>{if(!selected.size){alert('ابتدا سندها را انتخاب کنید.');return}if(confirm('اسناد انتخاب‌شده حذف شوند؟')){records=records.filter(r=>!selected.has(r.id));selected.clear();save()}};
function setupCanvas(id,clearId){
 const c=$(id);let active=false,last=null,ink=false;
 function fit(){const r=c.getBoundingClientRect(),d=window.devicePixelRatio||1;c.width=Math.round(r.width*d);c.height=Math.round(155*d);const x=c.getContext('2d');x.scale(d,d);x.lineWidth=2.3;x.lineCap='round';x.lineJoin='round';x.strokeStyle='#173b57';ink=false}
 fit();window.addEventListener('resize',fit);
 function pos(e){const r=c.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}
 c.addEventListener('pointerdown',e=>{active=true;ink=true;last=pos(e);c.setPointerCapture(e.pointerId)});
 c.addEventListener('pointermove',e=>{if(!active)return;const p=pos(e),x=c.getContext('2d');x.beginPath();x.moveTo(last.x,last.y);x.lineTo(p.x,p.y);x.stroke();last=p});
 ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>c.addEventListener(ev,()=>{active=false;last=null}));
 $(clearId).onclick=()=>{c.getContext('2d').clearRect(0,0,c.width,c.height);ink=false};
 return {has:()=>ink,data:()=>ink?c.toDataURL('image/png'):null,clear:()=>$(clearId).click()};
}
const ds=setupCanvas('deliverySig','clearDelivery'),rs=setupCanvas('receiptSig','clearReceipt');
function chosen(){return records.filter(r=>selected.has(r.id))}
$('registryUnit').onchange=()=>{$('registryUnitCustom').style.display=$('registryUnit').value==='custom'?'block':'none'};
$('applyDelivery').onclick=()=>{
 const list=chosen(),date=$('deliveryDate').value.trim()||today,signer=$('deliverySigner').value.trim(),unit=$('registryUnit').value==='محلات'?'ثبت محلات':$('registryUnitCustom').value.trim();
 if(!list.length){alert('ابتدا اسناد موردنظر را از فهرست انتخاب کنید.');return}
 if(list.some(r=>r.deliveryDate)){if(!confirm('بعضی اسناد قبلاً تحویل شده‌اند. تاریخ و امضای تحویل آن‌ها هم جایگزین شود؟'))return}
 if(!ds.has()){alert('امضای تحویل‌گیرنده اداره ثبت را ثبت کنید.');return}
 if(!signer){alert('نام و نام خانوادگی امضاکننده را وارد کنید.');return}
 if(!unit){alert('نام واحد ثبت را وارد کنید.');return}
 const sig=ds.data();list.forEach(r=>{r.deliveryDate=date;r.deliverySig=sig;r.deliverySigner=signer;r.registryUnit=unit});
 selected.clear();save();ds.clear();$('deliverySigner').value='';$('registryUnit').value='محلات';$('registryUnitCustom').value='';$('registryUnitCustom').style.display='none';alert('تاریخ، امضا و مشخصات واحد ثبت برای '+fa(list.length)+' سند ثبت شد.');
};
$('applyReceipt').onclick=()=>{
 const list=chosen(),date=$('receiptDate').value||today,receiver=$('receiptSigner').value.trim();
 if(!list.length){alert('ابتدا اسناد موردنظر را از فهرست انتخاب کنید.');return}
 if(list.some(r=>!r.deliveryDate)){alert('ابتدا همه اسناد انتخاب‌شده باید به اداره ثبت تحویل شده باشند.');return}
 if(list.some(r=>r.receiptDate)){if(!confirm('بعضی اسناد قبلاً دریافت شده‌اند. اطلاعات دریافت آن‌ها جایگزین شود؟'))return}
 if(!receiver){alert('ابتدا نام و نام خانوادگی گیرنده را وارد کنید.');return}
 const sig=rs.data();if(!sig){alert('پس از ثبت نام گیرنده، امضای او را ثبت کنید.');return}
 list.forEach(r=>{r.receiptDate=date;r.receiptSig=sig;r.receiptSigner=receiver});
 selected.clear();save();rs.clear();$('receiptSigner').value='';alert('تاریخ دریافت برای '+fa(list.length)+' سند ثبت شد.');
};
function downloadBackupInBrowser(json){const blob=new Blob([json],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='backup-registry-documents.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500)}
function restoreBackupJson(json){try{const data=JSON.parse(json);if(!Array.isArray(data)||data.some(r=>!r||typeof r!=='object'||Array.isArray(r)))throw Error();if(!confirm('اطلاعات فعلی با فایل پشتیبان جایگزین شود؟'))return;records=data;selected.clear();save();alert('بازیابی انجام شد. تعداد اسناد: '+fa(records.length))}catch(err){alert('فایل پشتیبان معتبر نیست یا ساختار آن اشتباه است.')}}
$('backup').onclick=()=>{try{const json=JSON.stringify(records,null,2);if(window.AndroidBridge&&typeof AndroidBridge.saveBackup==='function'){const b64=btoa(unescape(encodeURIComponent(json)));AndroidBridge.saveBackup(b64,'backup-registry-documents.json')}else{downloadBackupInBrowser(json)}}catch(err){alert('ساخت فایل پشتیبان انجام نشد.')}};
$('restoreBackupBtn').onclick=()=>{if(window.AndroidBridge&&typeof AndroidBridge.restoreBackup==='function'){AndroidBridge.restoreBackup()}else{$('restore').click()}};
$('restore').onchange=async e=>{const f=e.target.files&&e.target.files[0];if(!f)return;try{restoreBackupJson(await f.text())}catch{alert('خواندن فایل پشتیبان انجام نشد.')}e.target.value=''};
window.handleNativeBackup=function(base64){try{const binary=atob(base64),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0)),json=new TextDecoder('utf-8').decode(bytes);restoreBackupJson(json)}catch(err){alert('خواندن فایل پشتیبان انجام نشد.')}};
$('wipe').onclick=()=>{if(confirm('تمام اطلاعات این نرم‌افزار از این دستگاه پاک شود؟')){records=[];selected.clear();save()}};
$('printList').onclick=()=>{
 const list=chosen();
 if(!list.length){alert('ابتدا یک یا چند سند را انتخاب کنید.');return}
 const old=records; const oldFilter=filter;
 records=list; filter='all'; render(); window.print();
 records=old; filter=oldFilter; render();
};
$('exportWord').onclick=()=>{
 const list=chosen();
 if(!list.length){alert('ابتدا یک یا چند سند را از فهرست انتخاب کنید.');return}
 const cell=v=>`<td style="border:1px solid #555;padding:7px">${esc(v||'—')}</td>`;
 const rows=list.map((r,i)=>`<tr>${cell(fa(i+1))}${cell(r.office)}${cell(r.docdate)}${cell(r.barcode)}${cell(r.fullname)}${cell(r.mobile)}${cell(r.deliveryDate)}${cell(r.deliverySigner)}${cell(r.registryUnit)}${cell(r.receiptDate)}${cell(r.receiptSigner)}${cell(status(r))}</tr>`).join('');
 const html=`<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:Tahoma,Arial;direction:rtl}h2{text-align:center}table{border-collapse:collapse;width:100%;font-size:10pt}th{border:1px solid #555;background:#e8eef2;padding:7px}
/* ظاهر نهایی: تم روشن، آبی کاربنی و فهرست بلندتر */
.card{border-radius:22px;box-shadow:0 5px 20px #123b630d}
button{background:#174f86;border-radius:14px;min-height:42px}
button.secondary{background:#eaf1f8;color:#123b63}
button.green{background:#174f86}
input,textarea,select{border-radius:14px;border-color:#d3dfeb;min-height:44px}
.tablewrap{max-height:calc(100vh - 270px);min-height:360px;border-radius:16px}
.tablewrap table{min-width:1100px}
/* نمایش تمام‌صفحه فهرست اسناد */
.list-card.fullscreen{position:fixed;inset:0;z-index:9998;margin:0;padding:12px 12px 18px;border:0;border-radius:0;overflow:auto;background:#fff}
.list-card.fullscreen .list-fullscreen-head{position:sticky;top:-12px;z-index:5;background:#fff;padding:8px 0 10px;border-bottom:1px solid #e3eaf1}
.list-card.fullscreen .tablewrap{height:calc(100dvh - 310px);max-height:none;min-height:180px;overflow:auto}
.list-card.fullscreen .list-tools{grid-template-columns:repeat(2,minmax(0,1fr))}
.list-fullscreen-head{display:flex;align-items:center;justify-content:space-between;gap:10px}
.list-fullscreen-head h2{margin:0}
#closeListFullscreen{display:none;white-space:nowrap}
.list-card.fullscreen #closeListFullscreen{display:inline-flex}
#openListFullscreen{white-space:nowrap;padding:7px 12px;min-height:36px}
.exact-date-tools{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:end;margin:0 0 10px}
.exact-date-tools>div{min-width:0}
@media(max-width:620px){.list-card.fullscreen{padding:8px}.list-card.fullscreen .tablewrap{height:calc(100dvh - 390px);min-height:150px}.list-card.fullscreen .list-tools{grid-template-columns:1fr}.exact-date-tools{grid-template-columns:1fr auto}}
.list-tools{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-bottom:10px}
.list-tools input{min-width:0}
.edit-btn{padding:6px 10px;min-height:34px;white-space:nowrap}
.sig-name{font-weight:bold;color:#123b63;text-align:center;font-size:12px;margin-top:2px}
@media(max-width:620px){.tablewrap{max-height:calc(100vh - 240px);min-height:320px}.list-tools{grid-template-columns:1fr}.card{border-radius:19px}}
</style></head><body><h2>سامانه گردش اسناد</h2><p>گزارش اسناد انتخاب‌شده - تعداد: ${fa(list.length)}</p><table><thead><tr><th>ردیف</th><th>شماره دفترخانه</th><th>تاریخ سند</th><th>بارکد</th><th>نام گیرنده</th><th>موبایل</th><th>تاریخ تحویل</th><th>امضاکننده</th><th>واحد ثبت</th><th>تاریخ دریافت</th><th>نام گیرنده</th><th>وضعیت</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
 const base64=btoa(unescape(encodeURIComponent(html)));
 if(window.AndroidBridge&&AndroidBridge.saveWord){AndroidBridge.saveWord(base64,'گزارش-گردش-اسناد.doc');}
 else {alert('امکان ذخیره فایل Word در این محیط فراهم نیست.');}
};
$('docdate').value=today;$('deliveryDate').value=today;$('receiptDate').value=today;render();
