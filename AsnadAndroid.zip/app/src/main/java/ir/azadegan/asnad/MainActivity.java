package ir.azadegan.asnad;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.util.Base64;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

public class MainActivity extends Activity {
    private static final int CAMERA_REQUEST = 71;
    private static final int SAVE_WORD_REQUEST = 72;
    private static final int SAVE_BACKUP_REQUEST = 73;
    private static final int RESTORE_BACKUP_REQUEST = 74;
    private byte[] pendingWordBytes;
    private byte[] pendingBackupBytes;
    private WebView webView;
    private PermissionRequest pendingRequest;
    private final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void saveWord(String base64, String filename) {
                try {
                    pendingWordBytes = Base64.decode(base64, Base64.DEFAULT);
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/msword");
                    intent.putExtra(Intent.EXTRA_TITLE, filename);
                    startActivityForResult(intent, SAVE_WORD_REQUEST);
                } catch (Exception e) { runOnUiThread(() -> android.widget.Toast.makeText(MainActivity.this, "خطا در آماده‌سازی فایل Word", android.widget.Toast.LENGTH_LONG).show()); }
            }
            @JavascriptInterface public void saveBackup(String base64, String filename) {
                try {
                    pendingBackupBytes = Base64.decode(base64, Base64.DEFAULT);
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, filename);
                    runOnUiThread(() -> startActivityForResult(intent, SAVE_BACKUP_REQUEST));
                } catch (Exception e) { runOnUiThread(() -> android.widget.Toast.makeText(MainActivity.this, "خطا در آماده‌سازی فایل پشتیبان", android.widget.Toast.LENGTH_LONG).show()); }
            }
            @JavascriptInterface public void restoreBackup() {
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "application/octet-stream"});
                    startActivityForResult(intent, RESTORE_BACKUP_REQUEST);
                });
            }
        }, "AndroidBridge");
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsCamera = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) wantsCamera = true;
                    }
                    if (!wantsCamera) { request.deny(); return; }
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingRequest = request;
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
                    }
                });
            }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingRequest == request) pendingRequest = null;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_WORD_REQUEST) {
            if (resultCode == RESULT_OK && data != null && pendingWordBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) { out.write(new byte[]{(byte)0xEF,(byte)0xBB,(byte)0xBF}); out.write(pendingWordBytes); out.flush(); }
                    android.widget.Toast.makeText(this, "فایل Word ذخیره شد؛ می‌توانید آن را با Word باز و چاپ کنید.", android.widget.Toast.LENGTH_LONG).show();
                } catch (Exception e) { android.widget.Toast.makeText(this, "ذخیره فایل انجام نشد", android.widget.Toast.LENGTH_LONG).show(); }
            }
            pendingWordBytes = null;
        } else if (requestCode == SAVE_BACKUP_REQUEST) {
            if (resultCode == RESULT_OK && data != null && pendingBackupBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("Output stream unavailable");
                    out.write(pendingBackupBytes); out.flush();
                    android.widget.Toast.makeText(this, "فایل پشتیبان با موفقیت ذخیره شد.", android.widget.Toast.LENGTH_LONG).show();
                } catch (Exception e) { android.widget.Toast.makeText(this, "ذخیره فایل پشتیبان انجام نشد.", android.widget.Toast.LENGTH_LONG).show(); }
            }
            pendingBackupBytes = null;
        } else if (requestCode == RESTORE_BACKUP_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (InputStream in = getContentResolver().openInputStream(data.getData());
                     ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                    if (in == null) throw new Exception("Input stream unavailable");
                    byte[] chunk = new byte[8192]; int count;
                    while ((count = in.read(chunk)) != -1) buffer.write(chunk, 0, count);
                    String encoded = Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP);
                    webView.evaluateJavascript("window.handleNativeBackup('" + encoded + "')", null);
                } catch (Exception e) { android.widget.Toast.makeText(this, "خواندن فایل پشتیبان انجام نشد.", android.widget.Toast.LENGTH_LONG).show(); }
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_REQUEST && pendingRequest != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingRequest.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else { pendingRequest.deny(); }
            pendingRequest = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
