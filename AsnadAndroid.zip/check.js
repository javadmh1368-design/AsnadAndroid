
const $=id=>document.getElementById(id),today=new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()).replace(/-/g,'/');
// اسکن بارکد با دوربین گوشی (نیازمند پشتیبانی مرورگر و اجازه دسترسی دوربین)
let scannerStream=null,scannerTimer=null,scannerDetector=null,scannerBusy=false;
function stopBarcodeScanner(){
 if(scannerTimer){clearTimeout(scannerTimer);scannerTimer=null}
 if(scannerStream){scannerStream.getTracks().forEach(t=>t.stop());scannerStream=null}
 const v=$('scannerVideo');if(v)v.srcObject=null;
 $('scannerOverlay').style.display='none';scannerBusy=false;
}
async function startBarcodeScanner(){
 const overlay=$('scannerOverlay'),msg=$('scannerMessage'),video=$('scannerVideo');
 overlay.style.display='flex';msg.textContent='در حال آماده‌سازی دوربین...';
 if(!navigator.mediaDevices?.getUserMedia){msg.textContent='مرورگر اجازه باز کردن دوربین را نمی‌دهد. صفحه را در Chrome و از یک بستر امن (HTTPS) باز کنید.';return}
 try{
  if('BarcodeDetector' in window){
   let formats=['code_128','code_39','ean_13','ean_8','upc_a','upc_e','itf','codabar','qr_code'];
   if(BarcodeDetector.getSupportedFormats){const supported=await BarcodeDetector.getSupportedFormats();formats=formats.filter(f=>supported.includes(f));}
   scannerDetector=new BarcodeDetector({formats});
  }
  scannerStream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:'environment'}}});
  video.srcObject=scannerStream;await video.play();msg.textContent='دوربین را مقابل بارکد مرسوله بگیرید؛ اسکن به‌صورت خودکار انجام می‌شود.';
  scannerBusy=false;
  const scan=async()=>{
   if(!scannerStream||scannerBusy)return;
   if(video.readyState>=2 && scannerDetector){
    try{const found=await scannerDetector.detect(video);if(found&&found.length&&found[0].rawValue){
     const value=found[0].rawValue.trim();$('barcode').value=value;$('barcode').dispatchEvent(new Event('input',{bubbles:true}));
     msg.textContent='بارکد خوانده شد: '+value+'؛ حالا دکمه خواندن نوشته‌های بارنامه را بزنید.';scannerBusy=true;return;
    }}catch(e){}
   }
   if(scannerStream)scannerTimer=setTimeout(scan,180);
  };
  scan();
 }catch(err){
  let message='باز کردن دوربین ناموفق بود. اجازه دسترسی دوربین را فعال کنید و دوباره تلاش کنید.';
  if(err&&err.name==='NotAllowedError')message='اجازه دسترسی به دوربین داده نشد. از تنظیمات سایت، دسترسی Camera را فعال کنید.';
  else if(err&&err.name==='NotFoundError')message='دوربین قابل استفاده‌ای در گوشی پیدا نشد.';
  msg.textContent=message;
  if(scannerStream){scannerStream.getTracks().forEach(t=>t.stop());scannerStream=null}
 }
}
// خواندن نوشته‌های بارنامه با OCR؛ فقط فیلدهای موجود در سامانه پر می‌شوند.
function faDigits(v){return String(v||'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));}
function cleanDigits(v){return faDigits(v).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[^0-9]/g,'');}
function normalizeOcrText(v){return String(v||'').replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[‌‏]/g,' ').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));}
function extractLabelFields(text){
 const normalized=normalizeOcrText(text);
 const lines=normalized.split(/\n+/).map(x=>x.trim()).filter(Boolean);
 let mobile='';
 const all=normalized.replace(/[^0-9]/g,' ');
 const phones=all.match(/09\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d\s*\d/g)||[];
 if(phones.length) mobile=phones[phones.length-1];
 let name='',office='';
 for(let i=0;i<lines.length;i++){
  const line=lines[i].replace(/[\s:：]/g,'');
  if(!name && /نام(?:و)?نام?خانوادگی|نام.?گیرنده|گیرنده/.test(line)){
   const candidate=(lines[i].split(/[:：]/).slice(1).join(':').trim()||lines[i].replace(/.*?(?:نام\s*و?\s*نام\s*خانوادگی|نام\s*گیرنده|گیرنده)\s*/,'').trim()||lines[i+1]||'').trim();
   if(candidate && !/تلفن|موبایل|آدرس|کدپستی|دفترخانه/.test(candidate)) name=candidate;
  }
  if(!office && /دفترخانه/.test(line)){
   let candidate=(lines[i].split(/[:：]/).slice(1).join(':').trim()||lines[i].replace(/.*دفترخانه\s*/,'')).trim();
   if(!candidate){
    for(let j=i+1;j<Math.min(lines.length,i+3);j++){
     const next=lines[j].trim();
     if(next && !/تاریخ|شماره|بارکد|گیرنده|تلفن|موبایل|آدرس|کدپستی/.test(next)){candidate=next;break;}
    }
   }
   candidate=candidate.replace(/^(نام\s*)?(دفترخانه\s*)/,'').trim();
   if(candidate && !/^[:：\-]*$/.test(candidate)) office=candidate;
  }
 }
 return {mobile,name,office};
}
// موتور OCR و مدل زبان فقط یک‌بار ساخته می‌شوند و برای اسکن‌های بعدی نگه داشته می‌شوند.
let ocrWorkerPromise=null,ocrBusy=false;
async function getOcrWorker(msg){
 if(!window.Tesseract){await new Promise((resolve,reject)=>{const sc=document.createElement('script');sc.src='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';sc.onload=resolve;sc.onerror=reject;document.head.appendChild(sc)});}
 if(!ocrWorkerPromise){
  ocrWorkerPromise=Tesseract.createWorker('fas+eng',1,{logger:m=>{if(msg&&m.status==='recognizing text')msg.textContent='در حال تشخیص متن: '+Math.round((m.progress||0)*100)+'٪';}}).then(async worker=>{try{await worker.setParameters({tessedit_pageseg_mode:'6'});}catch(e){}return worker;}).catch(e=>{ocrWorkerPromise=null;throw e;});
 }
 return await ocrWorkerPromise;
}
$('readLabel').addEventListener('click',async()=>{
 const video=$('scannerVideo'),msg=$('scannerMessage'),button=$('readLabel');
 if(ocrBusy)return;
 if(!video.videoWidth){msg.textContent='ابتدا دوربین را باز کنید و بارنامه را در کادر قرار دهید.';return}
 ocrBusy=true;button.disabled=true;msg.textContent='در حال آماده‌سازی خواندن متن...';
 try{
  const worker=await getOcrWorker(msg);
  // کاهش اندازه تصویر تا OCR سریع‌تر شود، بدون تغییر نسبت تصویر.
  const c=$('ocrCanvas'),scale=Math.min(1,1600/video.videoWidth);
  c.width=Math.round(video.videoWidth*scale);c.height=Math.round(video.videoHeight*scale);
  const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(video,0,0,c.width,c.height);
  const result=await worker.recognize(c);
  const fields=extractLabelFields(result.data.text||'');
  if(fields.office){$('office').value=fields.office;$('office').dispatchEvent(new Event('input',{bubbles:true}));}
  if(fields.name){$('fullname').value=fields.name;$('fullname').dispatchEvent(new Event('input',{bubbles:true}));}
  if(fields.mobile){$('mobile').value=fields.mobile;$('mobile').dispatchEvent(new Event('input',{bubbles:true}));}
  const raw=normalizeOcrText(result.data.text||'');
  const nums=raw.match(/\d{10,20}/g)||[];
  if(!$('barcode').value && nums.length){$('barcode').value=nums[0];$('barcode').dispatchEvent(new Event('input',{bubbles:true}));}
  const found=[];if(fields.office)found.push('نام دفترخانه');if(fields.name)found.push('نام گیرنده');if(fields.mobile)found.push('موبایل گیرنده');if($('barcode').value)found.push('شماره بارنامه/بارکد');
  msg.textContent=found.length?'تشخیص انجام شد ('+found.join('، ')+'). فیلدها را بررسی و در صورت نیاز اصلاح کنید، سپس دوربین را ببندید.':'متن خوانده شد اما فیلدهای موردنظر با اطمینان تشخیص داده نشدند؛ لطفاً واضح‌تر عکس بگیرید یا دستی وارد کنید.';
 }catch(e){msg.textContent='خواندن متن ناموفق بود. اتصال اینترنت و اجازه دسترسی برنامه به اینترنت را بررسی کنید؛ بارنامه را واضح و روبه‌روی دوربین نگه دارید و دوباره تلاش کنید.';}
 finally{ocrBusy=false;button.disabled=false;}
});
$('openScanner').addEventListener('click',startBarcodeScanner);
$('closeScanner').addEventListener('click',stopBarcodeScanner);
$('scannerOverlay').addEventListener('click',e=>{if(e.target===$('scannerOverlay'))stopBarcodeScanner()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('scannerOverlay').style.display==='flex')stopBarcodeScanner()});

let records=JSON.parse(localStorage.getItem('registry_docs_v2')||'[]'),filter='all',selected=new Set();
const jalali=s=>{if(!s)return s;const m=String(s).match(/^(\d{4})-(\d{2})-(\d{2})$/);return m?new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(+m[1],+m[2]-1,+m[3])).replace(/-/g,'/'):s};
records.forEach(r=>{r.docdate=jalali(r.docdate);r.deliveryDate=jalali(r.deliveryDate);r.receiptDate=jalali(r.receiptDate)});
const fa=n=>Number(n).toLocaleString('fa-IR');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function save(){localStorage.setItem('registry_docs_v2',JSON.stringify(records));render()}
function status(r){return r.receiptDate?'دریافت‌شده':r.deliveryDate?'تحویل‌شده':'در انتظار تحویل'}
function render(){
 const query=($('searchDocs')?.value||'').trim().toLocaleLowerCase();
 const visible=records.filter(r=>(filter==='all'||(filter==='pending'&&!r.deliveryDate)||(filter==='delivered'&&r.deliveryDate&&!r.receiptDate)||(filter==='received'&&r.receiptDate))&&(!query||[r.office,r.docdate,r.barcode,r.fullname,r.mobile,r.deliveryDate,r.deliverySigner,r.registryUnit,r.receiptDate,status(r)].some(v=>String(v||'').toLocaleLowerCase().includes(query))));
 $('rows').innerHTML=visible.length?visible.map((r,i)=>`<tr><td class="noprint"><input type="checkbox" aria-label="انتخاب سند" ${selected.has(r.id)?'checked':''} onchange="toggle('${r.id}',this.checked)"></td><td>${fa(i+1)}</td><td>${esc(r.office)}</td><td>${esc(r.docdate)}</td><td>${esc(r.barcode)}</td><td>${esc(r.fullname)}</td><td>${esc(r.mobile)}</td><td>${esc(r.deliveryDate||'—')} ${r.deliverySig?'<span class="status done">امضا دارد</span>':''}</td><td>${esc(r.deliverySigner||'—')}</td><td>${esc(r.registryUnit||'—')}</td><td>${esc(r.receiptDate||'—')}</td><td>${r.deliverySig?`<img class="signature-print" src="${r.deliverySig}" alt="امضای تحویل">`:'—'}</td><td>${r.receiptSig?`<img class="signature-print" src="${r.receiptSig}" alt="امضای دریافت">`:'—'}</td><td><span class="status ${r.receiptDate?'done':''}">${status(r)}</span></td></tr>`).join(''):'<tr><td colspan="14" class="empty">موردی برای نمایش وجود ندارد.</td></tr>';
 $('sAll').textContent=fa(records.length);$('sPending').textContent=fa(records.filter(r=>!r.deliveryDate).length);$('sDelivered').textContent=fa(records.filter(r=>r.deliveryDate&&!r.receiptDate).length);$('sReceived').textContent=fa(records.filter(r=>r.receiptDate).length);
 document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter===filter));
}
$('searchDocs').addEventListener('input',render);
window.toggle=(id,on)=>{on?selected.add(id):selected.delete(id)};
$('add').onclick=()=>{
 const office=$('office').value.trim(),docdate=$('docdate').value,barcode=$('barcode').value.trim(),fullname=$('fullname').value.trim(),mobile=$('mobile').value.trim();
 if(!office||!docdate||!barcode||!fullname||!mobile){alert('لطفاً شماره دفترخانه، تاریخ، بارکد، نام و نام خانوادگی و موبایل را کامل کنید.');return}
 if(records.some(r=>r.barcode===barcode)){alert('این بارکد قبلاً ثبت شده است.');return}
 records.push({id:String(Date.now())+Math.random().toString(16).slice(2),office,docdate,barcode,fullname,mobile,deliveryDate:'',deliverySig:null,receiptDate:'',receiptSig:null});
 ['office','barcode','fullname','mobile'].forEach(id=>$(id).value='');save();alert('سند ثبت شد.');
};
document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;render()});
$('selectVisible').onclick=()=>{records.filter(r=>filter==='all'||(filter==='pending'&&!r.deliveryDate)||(filter==='delivered'&&r.deliveryDate&&!r.receiptDate)||(filter==='received'&&r.receiptDate)).forEach(r=>selected.add(r.id));render()};
$('unselect').onclick=()=>{selected.clear();render()};
$('deleteSelected').onclick=()=>{if(!selected.size){alert('ابتدا سندها را انتخاب کنید.');return}if(confirm('اسناد انتخاب‌شده حذف شوند؟')){records=records.filter(r=>!selected.has(r.id));selected.clear();save()}};
function setupCanvas(id,clearId){
 const c=$(id);let active=false,last=null,ink=false;
 function fit(){const r=c.getBoundingClientRect(),d=window.devicePixelRatio||1;c.width=Math.round(r.width*d);c.height=Math.round(155*d);const x=c.getContext('2d');x.scale(d,d);x.lineWidth=2.3;x.lineCap='round';x.lineJoin='round';x.strokeStyle='#173b57';ink=false}
 fit();window.addEventListener('resize',fit);
 function pos(e){const r=c.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}
 c.addEventListener('pointerdown',e=>{active=true;ink=true;last=pos(e);c.setPointerCapture(e.pointerId)});
 c.addEventListener('pointermove',e=>{if(!active)return;const p=pos(e),x=c.getContext('2d');x.beginPath();x.moveTo(last.x,last.y);x.lineTo(p.x,p.y);x.stroke();last=p});
 ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>c.addEventListener(ev,()=>{active=false;last=null}));
 $(clearId).onclick=()=>{c.getContext('2d').clearRect(0,0,c.width,c.height);ink=false};
 return {has:()=>ink,data:()=>ink?c.toDataURL('image/png'):null,clear:()=>$(clearId).click()};
}
const ds=setupCanvas('deliverySig','clearDelivery'),rs=setupCanvas('receiptSig','clearReceipt');
function chosen(){return records.filter(r=>selected.has(r.id))}
$('registryUnit').onchange=()=>{$('registryUnitCustom').style.display=$('registryUnit').value==='custom'?'block':'none'};
$('applyDelivery').onclick=()=>{
 const list=chosen(),date=$('deliveryDate').value.trim()||today,signer=$('deliverySigner').value.trim(),unit=$('registryUnit').value==='محلات'?'ثبت محلات':$('registryUnitCustom').value.trim();
 if(!list.length){alert('ابتدا اسناد موردنظر را از فهرست انتخاب کنید.');return}
 if(list.some(r=>r.deliveryDate)){if(!confirm('بعضی اسناد قبلاً تحویل شده‌اند. تاریخ و امضای تحویل آن‌ها هم جایگزین شود؟'))return}
 if(!ds.has()){alert('امضای تحویل‌گیرنده اداره ثبت را ثبت کنید.');return}
 if(!signer){alert('نام و نام خانوادگی امضاکننده را وارد کنید.');return}
 if(!unit){alert('نام واحد ثبت را وارد کنید.');return}
 const sig=ds.data();list.forEach(r=>{r.deliveryDate=date;r.deliverySig=sig;r.deliverySigner=signer;r.registryUnit=unit});
 selected.clear();save();ds.clear();$('deliverySigner').value='';$('registryUnit').value='محلات';$('registryUnitCustom').value='';$('registryUnitCustom').style.display='none';alert('تاریخ، امضا و مشخصات واحد ثبت برای '+fa(list.length)+' سند ثبت شد.');
};
$('applyReceipt').onclick=()=>{
 const list=chosen(),date=$('receiptDate').value||today;
 if(!list.length){alert('ابتدا اسناد موردنظر را از فهرست انتخاب کنید.');return}
 if(list.some(r=>!r.deliveryDate)){alert('ابتدا همه اسناد انتخاب‌شده باید به اداره ثبت تحویل شده باشند.');return}
 if(list.some(r=>r.receiptDate)){if(!confirm('بعضی اسناد قبلاً دریافت شده‌اند. اطلاعات دریافت آن‌ها جایگزین شود؟'))return}
 const sig=rs.data();if(!sig&&!confirm('امضای دریافت‌کننده خالی است. فقط تاریخ دریافت ثبت شود؟'))return;
 list.forEach(r=>{r.receiptDate=date;r.receiptSig=sig});
 selected.clear();save();rs.clear();alert('تاریخ دریافت برای '+fa(list.length)+' سند ثبت شد.');
};
function downloadBackupInBrowser(json){const blob=new Blob([json],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='backup-registry-documents.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500)}
function restoreBackupJson(json){try{const data=JSON.parse(json);if(!Array.isArray(data)||data.some(r=>!r||typeof r!=='object'||Array.isArray(r)))throw Error();if(!confirm('اطلاعات فعلی با فایل پشتیبان جایگزین شود؟'))return;records=data;selected.clear();save();alert('بازیابی انجام شد. تعداد اسناد: '+fa(records.length))}catch(err){alert('فایل پشتیبان معتبر نیست یا ساختار آن اشتباه است.')}}
$('backup').onclick=()=>{try{const json=JSON.stringify(records,null,2);if(window.AndroidBridge&&typeof AndroidBridge.saveBackup==='function'){const b64=btoa(unescape(encodeURIComponent(json)));AndroidBridge.saveBackup(b64,'backup-registry-documents.json')}else{downloadBackupInBrowser(json)}}catch(err){alert('ساخت فایل پشتیبان انجام نشد.')}};
$('restoreBackupBtn').onclick=()=>{if(window.AndroidBridge&&typeof AndroidBridge.restoreBackup==='function'){AndroidBridge.restoreBackup()}else{$('restore').click()}};
$('restore').onchange=async e=>{const f=e.target.files&&e.target.files[0];if(!f)return;try{restoreBackupJson(await f.text())}catch{alert('خواندن فایل پشتیبان انجام نشد.')}e.target.value=''};
window.handleNativeBackup=function(base64){try{const binary=atob(base64),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0)),json=new TextDecoder('utf-8').decode(bytes);restoreBackupJson(json)}catch(err){alert('خواندن فایل پشتیبان انجام نشد.')}};
$('wipe').onclick=()=>{if(confirm('تمام اطلاعات این نرم‌افزار از این دستگاه پاک شود؟')){records=[];selected.clear();save()}};
$('printList').onclick=()=>{
 const list=chosen();
 if(!list.length){alert('ابتدا یک یا چند سند را انتخاب کنید.');return}
 const old=records; const oldFilter=filter;
 records=list; filter='all'; render(); window.print();
 records=old; filter=oldFilter; render();
};
$('exportWord').onclick=()=>{
 const list=chosen();
 if(!list.length){alert('ابتدا یک یا چند سند را از فهرست انتخاب کنید.');return}
 const cell=v=>`<td style="border:1px solid #555;padding:7px">${esc(v||'—')}</td>`;
 const rows=list.map((r,i)=>`<tr>${cell(fa(i+1))}${cell(r.office)}${cell(r.docdate)}${cell(r.barcode)}${cell(r.fullname)}${cell(r.mobile)}${cell(r.deliveryDate)}${cell(r.deliverySigner)}${cell(r.registryUnit)}${cell(r.receiptDate)}${cell(status(r))}</tr>`).join('');
 const html=`<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:Tahoma,Arial;direction:rtl}h2{text-align:center}table{border-collapse:collapse;width:100%;font-size:10pt}th{border:1px solid #555;background:#e8eef2;padding:7px}</style></head><body><h2>سامانه گردش اسناد</h2><p>گزارش اسناد انتخاب‌شده - تعداد: ${fa(list.length)}</p><table><thead><tr><th>ردیف</th><th>شماره دفترخانه</th><th>تاریخ سند</th><th>بارکد</th><th>نام گیرنده</th><th>موبایل</th><th>تاریخ تحویل</th><th>امضاکننده</th><th>واحد ثبت</th><th>تاریخ دریافت</th><th>وضعیت</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
 const base64=btoa(unescape(encodeURIComponent(html)));
 if(window.AndroidBridge&&AndroidBridge.saveWord){AndroidBridge.saveWord(base64,'گزارش-گردش-اسناد.doc');}
 else {alert('امکان ذخیره فایل Word در این محیط فراهم نیست.');}
};
$('docdate').value=today;$('deliveryDate').value=today;$('receiptDate').value=today;render();
